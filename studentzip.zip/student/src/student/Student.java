import java.util.ArrayList;
import java.util.Scanner;

// Student class
class Student {

    // Private data members
    private int id;
    private String name;
    private String course;
    private double javaMarks;
    private double dbmsMarks;
    private double dsaMarks;

    // Constructor
    public Student(int id, String name, String course,
                   double javaMarks, double dbmsMarks, double dsaMarks) {

        this.id = id;
        this.name = name;
        this.course = course;
        this.javaMarks = javaMarks;
        this.dbmsMarks = dbmsMarks;
        this.dsaMarks = dsaMarks;
    }

    // Getter for ID
    public int getId() {
        return id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Setter for course
    public void setCourse(String course) {
        this.course = course;
    }

    // Setter for Java marks
    public void setJavaMarks(double javaMarks) {
        this.javaMarks = javaMarks;
    }

    // Setter for DBMS marks
    public void setDbmsMarks(double dbmsMarks) {
        this.dbmsMarks = dbmsMarks;
    }

    // Setter for DSA marks
    public void setDsaMarks(double dsaMarks) {
        this.dsaMarks = dsaMarks;
    }

    // Calculate total marks
    public double calculateTotal() {
        return javaMarks + dbmsMarks + dsaMarks;
    }

    // Calculate percentage
    public double calculatePercentage() {
        return calculateTotal() / 3;
    }

    // Calculate grade
    public String calculateGrade() {

        double percentage = calculatePercentage();

        if (percentage >= 90) {
            return "A+";
        } else if (percentage >= 80) {
            return "A";
        } else if (percentage >= 70) {
            return "B";
        } else if (percentage >= 60) {
            return "C";
        } else if (percentage >= 50) {
            return "D";
        } else {
            return "F";
        }
    }

    // Display student information
    public void displayStudent() {

        System.out.println("----------------------------------------");
        System.out.println("Student ID  : " + id);
        System.out.println("Name        : " + name);
        System.out.println("Course      : " + course);
        System.out.println("Java Marks  : " + javaMarks);
        System.out.println("DBMS Marks  : " + dbmsMarks);
        System.out.println("DSA Marks   : " + dsaMarks);
        System.out.println("Total Marks : " + calculateTotal() + "/300");
        System.out.printf("Percentage  : %.2f%%\n", calculatePercentage());
        System.out.println("Grade       : " + calculateGrade());
        System.out.println("----------------------------------------");
    }
}


// Main class
public class StudentManagementSystem {

    // ArrayList to store students
    static ArrayList<Student> students = new ArrayList<>();

    // Scanner object
    static Scanner scanner = new Scanner(System.in);


    // Method to add student
    public static void addStudent() {

        System.out.println("\n===== ADD STUDENT =====");

        System.out.print("Enter Student ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        // Check whether ID already exists
        for (Student student : students) {
            if (student.getId() == id) {
                System.out.println("Student ID already exists!");
                return;
            }
        }

        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Course: ");
        String course = scanner.nextLine();

        System.out.print("Enter Java Marks: ");
        double javaMarks = scanner.nextDouble();

        System.out.print("Enter DBMS Marks: ");
        double dbmsMarks = scanner.nextDouble();

        System.out.print("Enter DSA Marks: ");
        double dsaMarks = scanner.nextDouble();

        // Validate marks
        if (javaMarks < 0 || javaMarks > 100 ||
            dbmsMarks < 0 || dbmsMarks > 100 ||
            dsaMarks < 0 || dsaMarks > 100) {

            System.out.println("Marks must be between 0 and 100!");
            return;
        }

        // Create student object
        Student student = new Student(
                id,
                name,
                course,
                javaMarks,
                dbmsMarks,
                dsaMarks
        );

        // Add student to ArrayList
        students.add(student);

        System.out.println("Student added successfully!");
    }


    // Method to display all students
    public static void displayAllStudents() {

        System.out.println("\n===== ALL STUDENTS =====");

        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }

        for (Student student : students) {
            student.displayStudent();
        }
    }


    // Method to search student
    public static void searchStudent() {

        System.out.println("\n===== SEARCH STUDENT =====");

        System.out.print("Enter Student ID: ");
        int id = scanner.nextInt();

        for (Student student : students) {

            if (student.getId() == id) {

                System.out.println("Student found!");
                student.displayStudent();
                return;
            }
        }

        System.out.println("Student not found!");
    }


    // Method to update student
    public static void updateStudent() {

        System.out.println("\n===== UPDATE STUDENT =====");

        System.out.print("Enter Student ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        for (Student student : students) {

            if (student.getId() == id) {

                System.out.print("Enter New Name: ");
                String name = scanner.nextLine();

                System.out.print("Enter New Course: ");
                String course = scanner.nextLine();

                System.out.print("Enter New Java Marks: ");
                double javaMarks = scanner.nextDouble();

                System.out.print("Enter New DBMS Marks: ");
                double dbmsMarks = scanner.nextDouble();

                System.out.print("Enter New DSA Marks: ");
                double dsaMarks = scanner.nextDouble();

                // Validate marks
                if (javaMarks < 0 || javaMarks > 100 ||
                    dbmsMarks < 0 || dbmsMarks > 100 ||
                    dsaMarks < 0 || dsaMarks > 100) {

                    System.out.println("Marks must be between 0 and 100!");
                    return;
                }

                student.setName(name);
                student.setCourse(course);
                student.setJavaMarks(javaMarks);
                student.setDbmsMarks(dbmsMarks);
                student.setDsaMarks(dsaMarks);

                System.out.println("Student updated successfully!");
                return;
            }
        }

        System.out.println("Student not found!");
    }


    // Method to delete student
    public static void deleteStudent() {

        System.out.println("\n===== DELETE STUDENT =====");

        System.out.print("Enter Student ID: ");
        int id = scanner.nextInt();

        for (Student student : students) {

            if (student.getId() == id) {

                students.remove(student);

                System.out.println("Student deleted successfully!");
                return;
            }
        }

        System.out.println("Student not found!");
    }


    // Main method
    public static void main(String[] args) {

        int choice;

        do {

            System.out.println("\n========================================");
            System.out.println("       STUDENT MANAGEMENT SYSTEM");
            System.out.println("========================================");

            System.out.println("1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");

            System.out.println("========================================");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    addStudent();
                    break;

                case 2:
                    displayAllStudents();
                    break;

                case 3:
                    searchStudent();
                    break;

                case 4:
                    updateStudent();
                    break;

                case 5:
                    deleteStudent();
                    break;

                case 6:
                    System.out.println("Thank you for using Student Management System!");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }

        } while (choice != 6);

        scanner.close();
    }
}